// import logo from './logo.svg';
import './temp.css';
import React from 'react';
import Card from './components/temp';
import photo2 from './images/hero-cropped-image.jpg'

function App() {
  return (
    <React.Fragment>
      <header>
        {/* <div className="name-container">
          <span>Kim </span>
          <span>Taehyung</span>
        </div> */}
        <div className="img-container">
          <img src={photo2}/>
        </div>
      </header>
      <Card/>
    </React.Fragment>
  );
}

export default App;
