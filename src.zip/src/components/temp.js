import photo1 from '../images/card-image.jpg'

const Temp = () => {
  return(
    <section className="temp-section">
      <div className="temp-card">        
        <div className="box">
          <div className="imgBx">
            <img src={photo1} alt="taehyung's"/>
          </div>
          <div className="contentBx">
            <div>
              <p>
                Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum 
                Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum 
                Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum  
              </p>
              <h5>Song Name</h5>
            </div>
          </div>
        </div>      
      </div>
      <div className="temp-card">        
      <div className="box">
          <div className="imgBx">
            <img src={photo1} alt="taehyung's"/>
          </div>
          <div className="contentBx">
            <div>
              <p>
                Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum 
                Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum 
                Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum  
              </p>
              <h5>Song Name</h5>
            </div>
          </div>
        </div>       
      </div>
      <div className="temp-card">        
      <div className="box">
          <div className="imgBx">
            <img src={photo1} alt="taehyung's"/>
          </div>
          <div className="contentBx">
            <div>
              <p>
                Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum 
                Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum 
                Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum  
              </p>
              <h5>Song Name</h5>
            </div>
          </div>
        </div>       
      </div>
      <div className="temp-card">        
      <div className="box">
          <div className="imgBx">
            <img src={photo1} alt="taehyung's"/>
          </div>
          <div className="contentBx">
            <div>
              <p>
                Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum 
                Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum 
                Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum  
              </p>
              <h5>Song Name</h5>
            </div>
          </div>
        </div>       
      </div>
    </section>
  )
}

export default Temp;